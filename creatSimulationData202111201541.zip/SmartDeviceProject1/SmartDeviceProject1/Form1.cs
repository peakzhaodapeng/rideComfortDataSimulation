﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Collections;
using System.Diagnostics;
using System.IO;

namespace SmartDeviceProject1
{
    public partial class Form1 : Form
    {
        Int64 sampleTotalNum = 0;
        Single oneHundredthTotalNum = 0;

        double ch1Acc = 0;
        double ch2Acc = 0;
        double ch3Acc = 0;
        double ch4Speed = 0;


        public Form1()
        {
            InitializeComponent();            
        }        

        private void Form1_Load(object sender, EventArgs e)
        {             
            comboBoxCh1.Items.Add("正弦函数");
            comboBoxCh1.Items.Add("随机值");
            comboBoxCh1.Items.Add("恒定值");
            comboBoxCh1.Text = "正弦函数";

            comboBoxCh2.Items.Add("正弦函数");
            comboBoxCh2.Items.Add("随机值");
            comboBoxCh2.Items.Add("恒定值");
            comboBoxCh2.Text = "正弦函数";

            comboBoxCh3.Items.Add("正弦函数");
            comboBoxCh3.Items.Add("随机值");
            comboBoxCh3.Items.Add("恒定值");
            comboBoxCh3.Text = "正弦函数";
            
            comboBoxSpeed.Items.Add("噪声");
            comboBoxSpeed.Items.Add("恒定值");
            comboBoxSpeed.Text = "恒定值";
        }

        private void button1_Click(object sender, EventArgs e)
        {          
            
            saveFileDialog1.Filter = "*.odt|*.odt";
            saveFileDialog1.FileName = "originData" + DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss");
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {                
                FileStream fileStream = new FileStream(saveFileDialog1.FileName, FileMode.CreateNew);
                BinaryWriter binaryWriter = new BinaryWriter(fileStream);

                #region/*存储数据*/
                /*
                 * 1.获取采样点数
                 * 2.根据采样点数生成数据
                 * 3.将数据转换成十六进制数组
                 * 4.使用for循环存储数据
                 */
                sampleTotalNum = Convert.ToInt64(textBox7_sampleFreq.Text.ToString()) * Convert.ToInt64(textBox8_totalTime.Text.ToString());

                progressBar1.Minimum = 0;
                progressBar1.Maximum = (int)(sampleTotalNum - 1); 
                

                for (Int64 i = 0; i < sampleTotalNum; i++)
                {
                    progressBar1.Value =(int) i;
                    /*CH1 ACC*/
                    switch (comboBoxCh1.Text)
                    {
                        case "正弦函数":
                            ch1Acc = Convert.ToSingle(textBox1Amp.Text) * Math.Sin(2 * Math.PI * Convert.ToSingle(textBox2Freq.Text) + Convert.ToSingle(textBox3_phase.Text));
                            //ch1Acc = 3.14;
                            binaryWriter.Write(BitConverter.GetBytes(ch1Acc));
                            break;
                        case "随机值": 
                            Random randomNum=new Random();
                            double accRandomNum=randomNum.Next(0,Convert.ToInt16(textBox5ACCNoiseLimit.Text))/1.1;
                            ch1Acc = accRandomNum;
                            binaryWriter.Write(BitConverter.GetBytes(ch1Acc));
                            break;
                        case "恒定值":
                            ch1Acc = Convert.ToSingle(textBox9accSet.Text);
                            binaryWriter.Write(BitConverter.GetBytes(ch1Acc)); 
                            break;
                        default: break;
                    }
                    /*CH2 ACC*/
                    switch (comboBoxCh2.Text)
                    {
                        case "正弦函数":
                            ch2Acc = Convert.ToSingle(textBox1Amp.Text) * Math.Sin(2 * Math.PI * Convert.ToSingle(textBox2Freq.Text)*i + Convert.ToSingle(textBox3_phase.Text));
                            //ch2Acc = 3.14;
                            binaryWriter.Write(BitConverter.GetBytes(ch2Acc));
                            break;
                        case "随机值":
                            Random randomNum = new Random();
                            double accRandomNum = randomNum.Next(0, Convert.ToInt16(textBox5ACCNoiseLimit.Text)) / 1.1;
                            ch2Acc = accRandomNum;
                            binaryWriter.Write(BitConverter.GetBytes(ch2Acc));
                            break;
                        case "恒定值":
                            ch2Acc = Convert.ToSingle(textBox9accSet.Text);
                            binaryWriter.Write(BitConverter.GetBytes(ch2Acc));
                            break;
                        default: break;
                    }
                    /*CH3 ACC*/
                    switch (comboBoxCh3.Text)
                    {
                        case "正弦函数":
                            ch3Acc = Convert.ToSingle(textBox1Amp.Text) * Math.Sin(2 * Math.PI * Convert.ToSingle(textBox2Freq.Text)* + Convert.ToSingle(textBox3_phase.Text));
                            //ch3Acc = 3.14;
                            binaryWriter.Write(BitConverter.GetBytes(ch3Acc));
                            break;
                        case "随机值":
                            Random randomNum = new Random();
                            double accRandomNum = randomNum.Next(0, Convert.ToInt16(textBox5ACCNoiseLimit.Text)) / 1.1;
                            ch3Acc = accRandomNum;
                            binaryWriter.Write(BitConverter.GetBytes(ch3Acc));
                            break;
                        case "恒定值":
                            ch3Acc = Convert.ToSingle(textBox9accSet.Text);
                            binaryWriter.Write(BitConverter.GetBytes(ch3Acc));
                            break;
                        default: break;
                    }
                    /*CH4 Speed*/
                    switch (comboBoxSpeed.Text)
                    {
                        case "噪声":
                            Random randomNum = new Random();
                            double speedRandomNum = randomNum.Next(0, Convert.ToInt16(textBox6_speedNoiseLimit.Text)) / 1.1;
                            ch4Speed = speedRandomNum;
                            binaryWriter.Write(BitConverter.GetBytes(ch4Speed));
                            break;
                        case "恒定值":
                            ch4Speed = Convert.ToSingle(textBox4_speedSet.Text);
                            //ch4Speed = 20;
                            binaryWriter.Write(BitConverter.GetBytes(ch4Speed));
                            break;
                        default: break;
                    }
                }
                #endregion

                binaryWriter.Close();
                fileStream.Close();
            }

               
        }

        private void textBox1Amp_GotFocus(object sender, EventArgs e)
        {
            if (VarTEMP.getNewValue_f)
            {
                VarTEMP.getNewValue_f = false;
                textBox1Amp.Text = VarTEMP.keyboardRes.ToString();                
                VarTEMP.componentNo = 0;
                this.button1.Focus();                
            }
            else if (VarTEMP.keyBoardClose_f)
            {
                VarTEMP.keyBoardClose_f = false;
                this.button1.Focus();   
            }
            else
            {
                showKeyboard(1);                
            }            
        }

        private void textBox2Freq_GotFocus(object sender, EventArgs e)
        {
            if (VarTEMP.getNewValue_f)
            {
                VarTEMP.getNewValue_f = false;
                textBox2Freq.Text = VarTEMP.keyboardRes.ToString();                
                VarTEMP.componentNo = 0;
                this.button1.Focus();
            }
            else if (VarTEMP.keyBoardClose_f)
            {
                VarTEMP.keyBoardClose_f = false;
                this.button1.Focus();   
            }
            else
            {
                showKeyboard(2);                
            }      
        }

        private void textBox3_phase_GotFocus(object sender, EventArgs e)
        {
            if (VarTEMP.getNewValue_f)
            {
                VarTEMP.getNewValue_f = false;
                textBox3_phase.Text = VarTEMP.keyboardRes.ToString();
                VarTEMP.componentNo = 0;
                this.button1.Focus();
            }
            else if (VarTEMP.keyBoardClose_f)
            {
                VarTEMP.keyBoardClose_f = false;
                this.button1.Focus();   
            }
            else
            {
                showKeyboard(3);
            }      
        }

        private void textBox4_speedSet_GotFocus(object sender, EventArgs e)
        {
            if (VarTEMP.getNewValue_f)
            {
                VarTEMP.getNewValue_f = false;
                textBox4_speedSet.Text = VarTEMP.keyboardRes.ToString();
                VarTEMP.componentNo = 0;
                this.button1.Focus();
            }
            else if (VarTEMP.keyBoardClose_f)
            {
                VarTEMP.keyBoardClose_f = false;
                this.button1.Focus();   
            }
            else
            {
                showKeyboard(4);
            }      
        }

        private void textBox5ACCNoiseLimit_GotFocus(object sender, EventArgs e)
        {
            if (VarTEMP.getNewValue_f)
            {
                VarTEMP.getNewValue_f = false;
                textBox5ACCNoiseLimit.Text = VarTEMP.keyboardRes.ToString();
                VarTEMP.componentNo = 0;
                this.button1.Focus();
            }
            else if (VarTEMP.keyBoardClose_f)
            {
                VarTEMP.keyBoardClose_f = false;
                this.button1.Focus();   
            }
            else
            {
                showKeyboard(5);
            }      
        }

        private void textBox6_speedNoiseLimit_GotFocus(object sender, EventArgs e)
        {
            if (VarTEMP.getNewValue_f)
            {
                VarTEMP.getNewValue_f = false;
                textBox6_speedNoiseLimit.Text = VarTEMP.keyboardRes.ToString();
                VarTEMP.componentNo = 0;
                this.button1.Focus();
            }
            else if (VarTEMP.keyBoardClose_f)
            {
                VarTEMP.keyBoardClose_f = false;
                this.button1.Focus();   
            }
            else
            {
                showKeyboard(6);
            }      
        }

        private void textBox7_sampleFreq_GotFocus(object sender, EventArgs e)
        {
            if (VarTEMP.getNewValue_f)
            {
                VarTEMP.getNewValue_f = false;
                textBox7_sampleFreq.Text = VarTEMP.keyboardRes.ToString();
                VarTEMP.componentNo = 0;
                this.button1.Focus();
            }
            else if (VarTEMP.keyBoardClose_f)
            {
                VarTEMP.keyBoardClose_f = false;
                this.button1.Focus();   
            }
            else
            {
                showKeyboard(7);
            }      
        }

        private void textBox8_totalTime_GotFocus(object sender, EventArgs e)
        {
            if (VarTEMP.getNewValue_f)
            {
                VarTEMP.getNewValue_f = false;
                textBox8_totalTime.Text = VarTEMP.keyboardRes.ToString();
                VarTEMP.componentNo = 0;
                this.button1.Focus();
            }
            else if (VarTEMP.keyBoardClose_f)
            {
                VarTEMP.keyBoardClose_f = false;
                this.button1.Focus();   
            }
            else
            {
                showKeyboard(8);
            }      
        }
        private void showKeyboard(int num)
        {
            NumKeyBoard numKeyBoard = new NumKeyBoard();
            VarTEMP.componentNo = num;
            numKeyBoard.Left = VarTEMP.keyBoardLeft;
            numKeyBoard.Top = VarTEMP.keyBoardTop;
            numKeyBoard.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //openFileDialog1.Filter="*.odt|*.odt";

            string strData="";/*string 最大支持多大的数据，是不是应该用泛型*/
            if(openFileDialog1.ShowDialog()==DialogResult.OK)
            {
                FileStream fs1 = new FileStream(openFileDialog1.FileName,FileMode.Open,FileAccess.Read);
                BinaryReader BR = new BinaryReader(fs1);
                try
                {
                    //strData = BR.ReadString();
                    while (true)
                    {
                        //strData += " " + BR.ReadInt32().ToString();/*以Int32类型读出数据*/
                        //strData += " " + BR.ReadSingle().ToString();/*以single类型数据读出*/
                        strData += BR.ReadByte().ToString("X2");
                    }
                }
                catch (EndOfStreamException ES)
                {                 
                }
                textBox1.Text = strData;
                fs1.Close();
                BR.Close();
            }            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

       
    }
}