﻿namespace SmartDeviceProject1
{
    partial class NumKeyBoard
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.OkBtn = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.CloseBtn = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Dotbtn = new System.Windows.Forms.Button();
            this.MinusBtn = new System.Windows.Forms.Button();
            this.ClearBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Gray;
            this.button1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular);
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Location = new System.Drawing.Point(5, 67);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(79, 38);
            this.button1.TabIndex = 0;
            this.button1.Text = "1";
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Gray;
            this.button2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular);
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Location = new System.Drawing.Point(90, 67);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(79, 38);
            this.button2.TabIndex = 1;
            this.button2.Text = "2";
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Gray;
            this.button3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular);
            this.button3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button3.Location = new System.Drawing.Point(175, 67);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(79, 38);
            this.button3.TabIndex = 2;
            this.button3.Text = "3";
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Gray;
            this.button6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular);
            this.button6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button6.Location = new System.Drawing.Point(175, 111);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(79, 38);
            this.button6.TabIndex = 5;
            this.button6.Text = "6";
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Gray;
            this.button5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular);
            this.button5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button5.Location = new System.Drawing.Point(90, 111);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(79, 38);
            this.button5.TabIndex = 4;
            this.button5.Text = "5";
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Gray;
            this.button4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular);
            this.button4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button4.Location = new System.Drawing.Point(5, 111);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(79, 38);
            this.button4.TabIndex = 3;
            this.button4.Text = "4";
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Gray;
            this.button9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular);
            this.button9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button9.Location = new System.Drawing.Point(175, 155);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(79, 38);
            this.button9.TabIndex = 8;
            this.button9.Text = "9";
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Gray;
            this.button8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular);
            this.button8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button8.Location = new System.Drawing.Point(90, 155);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(79, 38);
            this.button8.TabIndex = 7;
            this.button8.Text = "8";
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Gray;
            this.button7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular);
            this.button7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button7.Location = new System.Drawing.Point(5, 155);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(79, 38);
            this.button7.TabIndex = 6;
            this.button7.Text = "7";
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // OkBtn
            // 
            this.OkBtn.BackColor = System.Drawing.Color.LimeGreen;
            this.OkBtn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular);
            this.OkBtn.Location = new System.Drawing.Point(175, 243);
            this.OkBtn.Name = "OkBtn";
            this.OkBtn.Size = new System.Drawing.Size(79, 38);
            this.OkBtn.TabIndex = 11;
            this.OkBtn.Text = "ok";
            this.OkBtn.Click += new System.EventHandler(this.OkBtn_Click);
            // 
            // button0
            // 
            this.button0.BackColor = System.Drawing.Color.Gray;
            this.button0.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular);
            this.button0.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button0.Location = new System.Drawing.Point(90, 199);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(79, 38);
            this.button0.TabIndex = 10;
            this.button0.Text = "0";
            this.button0.Click += new System.EventHandler(this.button0_Click);
            // 
            // CloseBtn
            // 
            this.CloseBtn.BackColor = System.Drawing.Color.Red;
            this.CloseBtn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular);
            this.CloseBtn.Location = new System.Drawing.Point(5, 243);
            this.CloseBtn.Name = "CloseBtn";
            this.CloseBtn.Size = new System.Drawing.Size(79, 38);
            this.CloseBtn.TabIndex = 9;
            this.CloseBtn.Text = "close";
            this.CloseBtn.Click += new System.EventHandler(this.CloseBtn_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Regular);
            this.textBox1.Location = new System.Drawing.Point(5, 14);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(249, 37);
            this.textBox1.TabIndex = 12;
            // 
            // Dotbtn
            // 
            this.Dotbtn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular);
            this.Dotbtn.Location = new System.Drawing.Point(5, 199);
            this.Dotbtn.Name = "Dotbtn";
            this.Dotbtn.Size = new System.Drawing.Size(79, 38);
            this.Dotbtn.TabIndex = 13;
            this.Dotbtn.Text = ".";
            this.Dotbtn.Click += new System.EventHandler(this.Dotbtn_Click);
            // 
            // MinusBtn
            // 
            this.MinusBtn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular);
            this.MinusBtn.Location = new System.Drawing.Point(175, 199);
            this.MinusBtn.Name = "MinusBtn";
            this.MinusBtn.Size = new System.Drawing.Size(79, 38);
            this.MinusBtn.TabIndex = 14;
            this.MinusBtn.Text = "-";
            this.MinusBtn.Click += new System.EventHandler(this.MinusBtn_Click);
            // 
            // ClearBtn
            // 
            this.ClearBtn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular);
            this.ClearBtn.Location = new System.Drawing.Point(90, 243);
            this.ClearBtn.Name = "ClearBtn";
            this.ClearBtn.Size = new System.Drawing.Size(79, 38);
            this.ClearBtn.TabIndex = 15;
            this.ClearBtn.Text = "clear";
            this.ClearBtn.Click += new System.EventHandler(this.ClearBtn_Click);
            // 
            // NumKeyBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.Desktop;
            this.ClientSize = new System.Drawing.Size(260, 286);
            this.ControlBox = false;
            this.Controls.Add(this.ClearBtn);
            this.Controls.Add(this.MinusBtn);
            this.Controls.Add(this.Dotbtn);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.OkBtn);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.CloseBtn);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "NumKeyBoard";
            this.Text = "NumKeyBoard";
            this.Load += new System.EventHandler(this.NumKeyBoard_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button OkBtn;
        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button CloseBtn;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button Dotbtn;
        private System.Windows.Forms.Button MinusBtn;
        private System.Windows.Forms.Button ClearBtn;
    }
}