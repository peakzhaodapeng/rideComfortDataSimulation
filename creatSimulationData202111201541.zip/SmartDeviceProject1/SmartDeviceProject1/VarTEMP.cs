﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace SmartDeviceProject1
{
    class VarTEMP
    {
        public static bool getNewValue_f;
        public static bool keyBoardClose_f;
        public static int componentNo;
        public static int keyBoardLeft = 382;
        public static int keyBoardTop = 155;
        public static float keyboardRes;
        
    }
}
