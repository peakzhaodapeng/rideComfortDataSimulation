﻿namespace SmartDeviceProject1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBoxCh1 = new System.Windows.Forms.ComboBox();
            this.comboBoxCh2 = new System.Windows.Forms.ComboBox();
            this.comboBoxCh3 = new System.Windows.Forms.ComboBox();
            this.comboBoxSpeed = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.phase_label9 = new System.Windows.Forms.Label();
            this.textBox1Amp = new System.Windows.Forms.TextBox();
            this.textBox2Freq = new System.Windows.Forms.TextBox();
            this.textBox3_phase = new System.Windows.Forms.TextBox();
            this.speedSet_label10 = new System.Windows.Forms.Label();
            this.textBox4_speedSet = new System.Windows.Forms.TextBox();
            this.textBox7_sampleFreq = new System.Windows.Forms.TextBox();
            this.textBox8_totalTime = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox5ACCNoiseLimit = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox6_speedNoiseLimit = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.label16 = new System.Windows.Forms.Label();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.button3 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox9accSet = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.YellowGreen;
            this.button1.Location = new System.Drawing.Point(722, 32);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(209, 67);
            this.button1.TabIndex = 0;
            this.button1.Text = "生成并保存数据";
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(40, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 20);
            this.label1.Text = "CH1 ACC";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(40, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 20);
            this.label2.Text = "CH2 ACC";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(40, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 20);
            this.label3.Text = "CH3 ACC";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(40, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 20);
            this.label4.Text = "CH4 Speed";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(40, 177);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 20);
            this.label5.Text = "采样频率";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(40, 210);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 20);
            this.label6.Text = "采样总时间";
            // 
            // comboBoxCh1
            // 
            this.comboBoxCh1.Location = new System.Drawing.Point(158, 32);
            this.comboBoxCh1.Name = "comboBoxCh1";
            this.comboBoxCh1.Size = new System.Drawing.Size(159, 23);
            this.comboBoxCh1.TabIndex = 11;
            // 
            // comboBoxCh2
            // 
            this.comboBoxCh2.Location = new System.Drawing.Point(158, 65);
            this.comboBoxCh2.Name = "comboBoxCh2";
            this.comboBoxCh2.Size = new System.Drawing.Size(159, 23);
            this.comboBoxCh2.TabIndex = 12;
            // 
            // comboBoxCh3
            // 
            this.comboBoxCh3.Location = new System.Drawing.Point(158, 101);
            this.comboBoxCh3.Name = "comboBoxCh3";
            this.comboBoxCh3.Size = new System.Drawing.Size(159, 23);
            this.comboBoxCh3.TabIndex = 13;
            // 
            // comboBoxSpeed
            // 
            this.comboBoxSpeed.Location = new System.Drawing.Point(158, 134);
            this.comboBoxSpeed.Name = "comboBoxSpeed";
            this.comboBoxSpeed.Size = new System.Drawing.Size(159, 23);
            this.comboBoxSpeed.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(386, 38);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 20);
            this.label7.Text = "amplitude";
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(386, 68);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 20);
            this.label8.Text = "frequency";
            // 
            // phase_label9
            // 
            this.phase_label9.Location = new System.Drawing.Point(386, 98);
            this.phase_label9.Name = "phase_label9";
            this.phase_label9.Size = new System.Drawing.Size(77, 20);
            this.phase_label9.Text = "phase";
            // 
            // textBox1Amp
            // 
            this.textBox1Amp.Location = new System.Drawing.Point(533, 35);
            this.textBox1Amp.Name = "textBox1Amp";
            this.textBox1Amp.Size = new System.Drawing.Size(100, 23);
            this.textBox1Amp.TabIndex = 20;
            this.textBox1Amp.Text = "1";
            this.textBox1Amp.GotFocus += new System.EventHandler(this.textBox1Amp_GotFocus);
            // 
            // textBox2Freq
            // 
            this.textBox2Freq.Location = new System.Drawing.Point(533, 65);
            this.textBox2Freq.Name = "textBox2Freq";
            this.textBox2Freq.Size = new System.Drawing.Size(100, 23);
            this.textBox2Freq.TabIndex = 21;
            this.textBox2Freq.Text = "1";
            this.textBox2Freq.GotFocus += new System.EventHandler(this.textBox2Freq_GotFocus);
            // 
            // textBox3_phase
            // 
            this.textBox3_phase.Location = new System.Drawing.Point(533, 98);
            this.textBox3_phase.Name = "textBox3_phase";
            this.textBox3_phase.Size = new System.Drawing.Size(100, 23);
            this.textBox3_phase.TabIndex = 22;
            this.textBox3_phase.Text = "1";
            this.textBox3_phase.GotFocus += new System.EventHandler(this.textBox3_phase_GotFocus);
            // 
            // speedSet_label10
            // 
            this.speedSet_label10.Location = new System.Drawing.Point(386, 137);
            this.speedSet_label10.Name = "speedSet_label10";
            this.speedSet_label10.Size = new System.Drawing.Size(77, 20);
            this.speedSet_label10.Text = "speedSet";
            // 
            // textBox4_speedSet
            // 
            this.textBox4_speedSet.Location = new System.Drawing.Point(533, 134);
            this.textBox4_speedSet.Name = "textBox4_speedSet";
            this.textBox4_speedSet.Size = new System.Drawing.Size(100, 23);
            this.textBox4_speedSet.TabIndex = 24;
            this.textBox4_speedSet.Text = "11";
            this.textBox4_speedSet.GotFocus += new System.EventHandler(this.textBox4_speedSet_GotFocus);
            // 
            // textBox7_sampleFreq
            // 
            this.textBox7_sampleFreq.Location = new System.Drawing.Point(158, 174);
            this.textBox7_sampleFreq.Name = "textBox7_sampleFreq";
            this.textBox7_sampleFreq.Size = new System.Drawing.Size(100, 23);
            this.textBox7_sampleFreq.TabIndex = 25;
            this.textBox7_sampleFreq.Text = "100";
            this.textBox7_sampleFreq.GotFocus += new System.EventHandler(this.textBox7_sampleFreq_GotFocus);
            // 
            // textBox8_totalTime
            // 
            this.textBox8_totalTime.Location = new System.Drawing.Point(158, 207);
            this.textBox8_totalTime.Name = "textBox8_totalTime";
            this.textBox8_totalTime.Size = new System.Drawing.Size(100, 23);
            this.textBox8_totalTime.TabIndex = 26;
            this.textBox8_totalTime.Text = "1";
            this.textBox8_totalTime.GotFocus += new System.EventHandler(this.textBox8_totalTime_GotFocus);
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(264, 177);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 20);
            this.label9.Text = "Hz";
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(264, 207);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 20);
            this.label10.Text = "s";
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(639, 137);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 20);
            this.label11.Text = "km/h";
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(639, 101);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(49, 20);
            this.label12.Text = "rad";
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(639, 68);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(49, 20);
            this.label13.Text = "Hz";
            // 
            // textBox5ACCNoiseLimit
            // 
            this.textBox5ACCNoiseLimit.Location = new System.Drawing.Point(533, 171);
            this.textBox5ACCNoiseLimit.Name = "textBox5ACCNoiseLimit";
            this.textBox5ACCNoiseLimit.Size = new System.Drawing.Size(100, 23);
            this.textBox5ACCNoiseLimit.TabIndex = 38;
            this.textBox5ACCNoiseLimit.GotFocus += new System.EventHandler(this.textBox5ACCNoiseLimit_GotFocus);
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(386, 174);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(112, 20);
            this.label15.Text = "AccNoiseLimit";
            // 
            // textBox6_speedNoiseLimit
            // 
            this.textBox6_speedNoiseLimit.Location = new System.Drawing.Point(533, 204);
            this.textBox6_speedNoiseLimit.Name = "textBox6_speedNoiseLimit";
            this.textBox6_speedNoiseLimit.Size = new System.Drawing.Size(100, 23);
            this.textBox6_speedNoiseLimit.TabIndex = 42;
            this.textBox6_speedNoiseLimit.GotFocus += new System.EventHandler(this.textBox6_speedNoiseLimit_GotFocus);
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(386, 207);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(112, 20);
            this.label14.Text = "SpeedNoiseLimit";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(40, 275);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(637, 18);
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(40, 252);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(100, 20);
            this.label16.Text = "生成进度";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Khaki;
            this.button2.Location = new System.Drawing.Point(722, 115);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(209, 67);
            this.button2.TabIndex = 60;
            this.button2.Text = "读取数据";
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(29, 299);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(975, 244);
            this.textBox1.TabIndex = 61;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Tomato;
            this.button3.Location = new System.Drawing.Point(722, 210);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(209, 67);
            this.button3.TabIndex = 62;
            this.button3.Text = "clear";
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(639, 242);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(49, 20);
            this.label17.Text = "m/s^2";
            // 
            // textBox9accSet
            // 
            this.textBox9accSet.Location = new System.Drawing.Point(533, 239);
            this.textBox9accSet.Name = "textBox9accSet";
            this.textBox9accSet.Size = new System.Drawing.Size(100, 23);
            this.textBox9accSet.TabIndex = 84;
            this.textBox9accSet.Text = "11";
            // 
            // label18
            // 
            this.label18.Location = new System.Drawing.Point(386, 242);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(77, 20);
            this.label18.Text = "accSet";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1022, 575);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.textBox9accSet);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.textBox6_speedNoiseLimit);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.textBox5ACCNoiseLimit);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBox8_totalTime);
            this.Controls.Add(this.textBox7_sampleFreq);
            this.Controls.Add(this.textBox4_speedSet);
            this.Controls.Add(this.speedSet_label10);
            this.Controls.Add(this.textBox3_phase);
            this.Controls.Add(this.textBox2Freq);
            this.Controls.Add(this.textBox1Amp);
            this.Controls.Add(this.phase_label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.comboBoxSpeed);
            this.Controls.Add(this.comboBoxCh3);
            this.Controls.Add(this.comboBoxCh2);
            this.Controls.Add(this.comboBoxCh1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBoxCh1;
        private System.Windows.Forms.ComboBox comboBoxCh2;
        private System.Windows.Forms.ComboBox comboBoxCh3;
        private System.Windows.Forms.ComboBox comboBoxSpeed;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label phase_label9;
        private System.Windows.Forms.TextBox textBox1Amp;
        private System.Windows.Forms.TextBox textBox2Freq;
        private System.Windows.Forms.TextBox textBox3_phase;
        private System.Windows.Forms.Label speedSet_label10;
        private System.Windows.Forms.TextBox textBox4_speedSet;
        private System.Windows.Forms.TextBox textBox7_sampleFreq;
        private System.Windows.Forms.TextBox textBox8_totalTime;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox5ACCNoiseLimit;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox6_speedNoiseLimit;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox9accSet;
        private System.Windows.Forms.Label label18;


    }
}

